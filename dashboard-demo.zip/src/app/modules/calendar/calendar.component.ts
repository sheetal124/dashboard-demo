import { Component, OnInit } from '@angular/core';
import { HeaderTitleService } from 'src/app/shared/services/header-title.service';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss']
})
export class CalendarComponent implements OnInit {

  constructor(private headerService: HeaderTitleService) { }

  ngOnInit(): void {
    this.headerService.setTitle('Calendar');
  }

}
