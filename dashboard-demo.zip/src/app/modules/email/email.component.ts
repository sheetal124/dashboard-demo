import { Component, OnInit } from '@angular/core';
import { HeaderTitleService } from 'src/app/shared/services/header-title.service';

@Component({
  selector: 'app-email',
  templateUrl: './email.component.html',
  styleUrls: ['./email.component.scss']
})
export class EmailComponent implements OnInit {

  constructor(private headerService: HeaderTitleService) { }

  ngOnInit(): void {
    this.headerService.setTitle('Email');
  }

}
