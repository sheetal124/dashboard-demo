import { TicketModalService } from './../services/ticket-modal.service';
import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-ticket-list',
  templateUrl: './ticket-list.component.html',
  styleUrls: ['./ticket-list.component.scss']
})
export class TicketListComponent implements OnInit {
  @Input() TicketsData: any;
  @Output() dltId = new EventEmitter<any>();
  @Output() editData = new EventEmitter<any>();
  @Output() isAddClicked = new EventEmitter<boolean>();
  @Output() ismodalopenchecked = new EventEmitter<boolean>();
  searchText: any;
  searchField: any;
  isDesc: boolean = false;
  column: string;
  constructor(private ticketModalService:TicketModalService) { }

  ngOnInit(): void {
  }
  search() {
    if (this.searchField == "") {
      this.ngOnInit();
    } else {
      this.TicketsData = this.TicketsData.filter((res: { requestBy: string; }) => {
        return res.requestBy.toLocaleLowerCase().match(this.searchField.toLocaleLowerCase())
      })
    }
  }
  sort(property: any) {
    this.isDesc = !this.isDesc; //change the direction    
    this.column = property;
    let direction = this.isDesc ? 1 : -1;

    this.TicketsData.sort(function (a: any, b: any) {
      if (a[property] < b[property]) {
        return -1 * direction;
      }
      else if (a[property] > b[property]) {
        return 1 * direction;
      }
      else {
        return 0;
      }
    });
  };
  deleteTicket(tickitid: number) {
    this.dltId.emit(tickitid);
  }
  editTicketData(ticket: any) {
    this.openModal(true);
    this.checkIfedit(true)
    this.checkIfSave(false);
    this.editData.emit(ticket);
  }
  openModal(status: boolean) {
    this.ticketModalService.toggleModal(status);
    this.checkIfedit(false)
    this.checkIfSave(true);
    this.ismodalopenchecked.emit(true);
  }
  checkIfedit(status:boolean){
    this.ticketModalService.toggleEditBtn(status);
  }
  checkIfSave(status:boolean){
    this.ticketModalService.toggleSaveBtn(status);
  }
}
