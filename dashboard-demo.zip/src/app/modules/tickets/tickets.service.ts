import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Tickets } from './tickets';

@Injectable({
  providedIn: 'root'
})
export class TicketsService {
  url: string = "http://localhost:3000/"

  constructor(private http: HttpClient) { }
  getTickets():Observable<Tickets[]>{
    return this.http.get<Tickets[]>(`${this.url}tickets`);
  }
  deleteTickets(id:number):Observable<Tickets[]>{
    return this.http.delete<Tickets[]>(`${this.url}tickets/${id}`)
  }
  addNewTickets(data:Tickets):Observable<Tickets[]>{
    return this.http.post<Tickets[]>(`${this.url}tickets`,data)
  }
  editTickets(data:Tickets):Observable<Tickets[]> {
    return this.http.put<Tickets[]>(`${this.url}tickets/${data.id}`, data);
  }
}