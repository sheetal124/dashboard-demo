import { TicketModalService } from './services/ticket-modal.service';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HeaderTitleService } from 'src/app/shared/services/header-title.service';
import { Tickets } from './tickets';
import { TicketsService } from './tickets.service';
@Component({
  selector: 'app-tickets',
  templateUrl: './tickets.component.html',
  styleUrls: ['./tickets.component.scss'],
})
export class TicketsComponent implements OnInit {
  // ticketsForm: FormGroup;
  Tickets: any = [];
  updatedTicket: any;
  newupdateData: any;
  isModalOpen: boolean;
  isUpdatebtnshow: boolean;
  isSavebtnshow: boolean;
  // isUpdatebtnshown:boolean=false;
  // isSavebtnshow:boolean=true;
  // searchText: any;
  // searchField: any;
  // isDesc: boolean = false;
  // column: string = 'CategoryName';
  // updateTickets: any;
  constructor(private ticketSrvice: TicketsService,
    private fb: FormBuilder,
    private headerService: HeaderTitleService,
    private ticketModalService: TicketModalService) {
    // this.buildForm();
  }

  ngOnInit(): void {
    this.getTicketsdata();
    this.toggleTicketModal();
    this.headerService.setTitle('Tickets');
  }

  toggleTicketModal() {
    this.ticketModalService.getModalStatus().subscribe((res: boolean) => {
      this.isModalOpen = res;
    });
    this.ticketModalService.getEditBtnStatus().subscribe((res: boolean) => {
      this.isUpdatebtnshow = res;
    });
    this.ticketModalService.getSaveBtnStatus().subscribe((res: boolean) => {
      this.isSavebtnshow = res;
    })
  }
  getTicketsdata() {
    this.ticketSrvice.getTickets().subscribe(
      (Tickets: any) => {
        this.Tickets = Tickets
      }
    )
  }

  addTickets(addedTickets: any) {
    debugger
    this.ticketSrvice.addNewTickets(addedTickets).subscribe(
      () => {
        this.getTicketsdata();
      }
    )

  }
  deleteTicketData(id: number) {
    this.ticketSrvice.deleteTickets(id).subscribe((res) => {
      this.getTicketsdata();
      console.log(id);
    })
  }
  editTicket(newticketdata: Tickets) {
    this.updatedTicket = newticketdata;
    console.log(this.updatedTicket);
  }
  updateTicketData(newupdateData: any) {
    this.ticketSrvice.editTickets(newupdateData).subscribe(
      (res) => {
        console.log(res);

        this.getTicketsdata();
        console.log(newupdateData);
      }
    )
  }
}
