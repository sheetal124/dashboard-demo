import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable()
export class TicketModalService {

  isModalOpen: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  isEditBtnShown:BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  isSaveBtnShown:BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
  constructor() { }

  // sending/emiting status 
  toggleModal(modalStatus: boolean) {
    this.isModalOpen.next(modalStatus);
  }
  // listening to status by subscribing it
  getModalStatus(): Observable<boolean> {
    return this.isModalOpen.asObservable();
  }
  toggleEditBtn(checkedit:boolean){
    this.isEditBtnShown.next(checkedit);
  }
  getEditBtnStatus():Observable<boolean> {
    return this.isEditBtnShown.asObservable();
  }
  toggleSaveBtn(checkadd:boolean){
    this.isSaveBtnShown.next(checkadd);
  }
  getSaveBtnStatus():Observable<boolean> {
    return this.isSaveBtnShown.asObservable();
  }
}
