export class Tickets{
    id?:number;
    requestBy?:string;
    subject?:string;
    assignee?:File;
    priority?:string;
    status?:string;
    createDate?:Date;
    dueDate?:Date;
    constructor(id?:number,requestBy?:string,subject?:string,assignee?:File,priority?:string,status?:string,
    createDate?:Date, dueDate?:Date){
        this.id = id;
        this.requestBy = requestBy;
        this.subject = subject;
        this.assignee = assignee;
        this.priority = priority;
        this.status = status;
        this.createDate = createDate;
        this.dueDate = dueDate;
    }

}