import { TicketModalService } from './services/ticket-modal.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TicketsRoutingModule } from './tickets-routing.module';
import { TicketsComponent } from './tickets.component';
import { HttpClientModule } from '@angular/common/http';
import { TicketsService } from './tickets.service';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { SharedModule } from 'src/app/shared/shared.module';
import { SortPipe } from 'src/app/shared/pipes/sort.pipe';
import { TicketListComponent } from './ticket-list/ticket-list.component';
import { TicketFormComponent } from './ticket-form/ticket-form.component';


@NgModule({
  declarations: [
    TicketsComponent,
    TicketListComponent,
    TicketFormComponent
  ],
  imports: [
    CommonModule,
    TicketsRoutingModule,
    HttpClientModule,
    Ng2OrderModule,
    FormsModule,
    ReactiveFormsModule,
    Ng2SearchPipeModule,
    SharedModule
  ],
  providers: [
   TicketsService,
   TicketModalService
  ]
})
export class TicketsModule { }
