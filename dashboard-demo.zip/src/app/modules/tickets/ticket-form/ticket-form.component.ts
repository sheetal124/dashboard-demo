import { TicketModalService } from './../services/ticket-modal.service';
import { Component, OnInit, Output, EventEmitter, Input, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Tickets } from '../tickets';

@Component({
  selector: 'app-ticket-form',
  templateUrl: './ticket-form.component.html',
  styleUrls: ['./ticket-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TicketFormComponent implements OnInit {
  ticketsForm: FormGroup;
  ticketDetails: Tickets = new Tickets()
  isUpdatebtnshown: boolean = false;
  // isSavebtnshow: boolean = true;
  @Output() ticketData = new EventEmitter<any>();
  @Output() newupdatedTicketData = new EventEmitter<any>();
  @Input() isModalOpen: boolean;
  @Input() isSavebtnshow: boolean;
  @Input() isUpdatebtnshow: boolean;
  @Input() public set updatedTicketData(ticket: Tickets) {
    this.patchFormValues(ticket);
  }
  public get updatedTicketData(): Tickets {
    return this.updatedTicketData
  }
  constructor(private fb: FormBuilder, private ts: TicketModalService) {
  }

  ngOnInit(): void {
    this.buildForm();
  }
  saveTicketData() {
    this.ticketData.emit(this.ticketsForm.value);
    this.closeModal(false);
  }
  patchFormValues(values: Tickets) {
    values && this.ticketsForm.patchValue(values);
  }
  buildForm() {
    this.ticketsForm = this.fb.group({
      id: [''],
      requestBy: [''],
      subject: [''],
      assignee: [''],
      priority: [''],
      status: [''],
      createDate: [''],
      dueDate: ['']
    })
  }
  updateTicketData() {
    this.newupdatedTicketData.emit(this.ticketsForm.value);
    this.closeModal(false);
  }

  closeModal(status: boolean) {
    this.ts.toggleModal(status);
    this.ticketsForm.reset();
  }
}
