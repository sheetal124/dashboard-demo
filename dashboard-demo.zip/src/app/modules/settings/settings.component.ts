import { Component, OnInit } from '@angular/core';
import { HeaderTitleService } from 'src/app/shared/services/header-title.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {

  constructor(private headerService: HeaderTitleService) { }

  ngOnInit(): void {
    this.headerService.setTitle('Settings');
  }

}
