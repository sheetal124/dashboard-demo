import { Component, OnInit } from '@angular/core';
import { HeaderTitleService } from 'src/app/shared/services/header-title.service';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.scss']
})
export class TaskComponent implements OnInit {

  constructor(private headerService: HeaderTitleService) { }

  ngOnInit(): void {
    this.headerService.setTitle('Task');
  }

}
