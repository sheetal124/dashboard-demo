import { Component, OnInit } from '@angular/core';
import { HeaderTitleService } from 'src/app/shared/services/header-title.service';

@Component({
  selector: 'app-authentication',
  templateUrl: './authentication.component.html',
  styleUrls: ['./authentication.component.scss']
})
export class AuthenticationComponent implements OnInit {

  constructor(private headerService: HeaderTitleService) { }

  ngOnInit(): void {
    this.headerService.setTitle('Authentication');
  }

}
