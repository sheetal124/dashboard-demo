import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'ticket',
    pathMatch: 'full'
  },
  {
    path:'ticket',
    loadChildren: () => import('./modules/tickets/tickets.module').then(m => m.TicketsModule),
    data:{title:'ticket'}
  },
  {
    path:'authentication',
    loadChildren: () => import('./modules/authentication/authentication.module').then(m => m.AuthenticationModule),
    data:{title:'authentication'}
  },
  {
    path:'calendar',
    loadChildren: () => import('./modules/calendar/calendar.module').then(m => m.CalendarModule),
    data:{title:'calendar'}
  },
  {
    path:'chats',
    loadChildren: () => import('./modules/chats/chats.module').then(m => m.ChatsModule),
    data:{title:'chats'}
  },
  {
    path:'companies',
    loadChildren: () => import('./modules/companies/companies.module').then(m => m.CompaniesModule),
    data:{title:'companies'}
  },
  {
    path:'dashboard',
    loadChildren: () => import('./modules/dashboard/dashboard.module').then(m => m.DashboardModule),
    data:{title:'dashboard'}
  },
  {
    path:'email',
    loadChildren: () => import('./modules/email/email.module').then(m => m.EmailModule),
    data:{title:'email'}
  },
  {
    path:'file-manager',
    loadChildren: () => import('./modules/file-manager/file-manager.module').then(m => m.FileManagerModule),
    data:{title:'file-manager'}
  },
  {
    path:'settings',
    loadChildren: () => import('./modules/settings/settings.module').then(m => m.SettingsModule),
    data:{title:'settings'}
  },
  {
    path:'task',
    loadChildren: () => import('./modules/task/task.module').then(m => m.TaskModule),
    data:{title:'task'}
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
