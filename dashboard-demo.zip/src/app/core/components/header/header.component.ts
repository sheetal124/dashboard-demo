import { Component, OnInit } from '@angular/core';
import { HeaderTitleService } from 'src/app/shared/services/header-title.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  title = '';
  constructor(private headerService: HeaderTitleService) { }

  ngOnInit(): void {
    this.headerService.title.subscribe(title => {
      this.title = title;
    });
  }

}
